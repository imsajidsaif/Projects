from flask import *
import re
import pandas as pd
app = Flask(__name__)

@app.route("/tables")
def show_tables():
    from selenium import webdriver
    import time
    import pandas as pd
    import numpy as np
    from bs4 import BeautifulSoup
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    game_url = 'https://play.google.com/store/apps/details?id=it.rortos.airfighters&showAllReviews=true'
    param_option = webdriver.ChromeOptions()
    chromedriver = r'chromedriver.exe'
    driver = webdriver.Chrome(chromedriver, options=param_option)
    driver.get(game_url)
    html_source = driver.page_source

    soup=BeautifulSoup(html_source, "html.parser")
    
    rating=[]
    reviews = WebDriverWait(driver, 10).until(EC.visibility_of_all_elements_located((By.XPATH, "//h3[.='User reviews']/following-sibling::div[1]/div")))
    for review in reviews:
        try:
            rating.append(review.find_element_by_xpath(".//div[@role='img']").get_attribute('aria-label'))
        except:
            continue
    
    review_content_text = soup.find_all('div',{'class', 'UD7Dzf'})
    review_content_text_list = []
    for val in review_content_text:
        review_content_text_list.append(val.get_text())
    for i in range(len(rating)):
        rating[i]=int(re.findall('\d',rating[i])[0])
    
    df=pd.DataFrame({"Review":review_content_text_list,"Rating":rating})
    df.to_csv("csv_file.csv")
    
    postive_review=df[df.Rating==5]
    negative_review=df[df.Rating==1]
    
    return render_template('index.html',tables=[postive_review.to_html(classes='postive_review'), negative_review.to_html(classes='negative_review')],
    titles = ['na', 'Postive Review', 'Negative Review'])
    from wordcloud import WordCloud, STOPWORDS
    import matplotlib.pyplot as plt
    import pandas as pd
    comment_words = ''
    stopwords = set(STOPWORDS)
    for itr in postive_review.Review:
        itr = str(itr)
        tokens = itr.split()
        for i in range(len(tokens)):
            tokens[i] = tokens[i].lower()
        comment_words += " ".join(tokens)+" "
    wordcloud = WordCloud(width = 1000, height = 600,background_color ='black',stopwords = stopwords,min_font_size = 10).generate(comment_words)
    plt.figure(figsize = (16, 8))
    plt.savefig('static/positive_review_wordcloud.png')
    from wordcloud import WordCloud, STOPWORDS
    import matplotlib.pyplot as plt
    import pandas as pd
    comment_words = ''
    stopwords = set(STOPWORDS)
    for itr in negative_review.Review:
        itr = str(itr)
        tokens = itr.split()
        for i in range(len(tokens)):
            tokens[i] = tokens[i].lower()
        comment_words += " ".join(tokens)+" "
    wordcloud = WordCloud(width = 1000, height = 600,background_color ='black',stopwords = stopwords,min_font_size = 10).generate(comment_words)
    print(".......................",comment_words)
    plt.figure(figsize = (16, 8))
    plt.savefig('static/negative_review_wordcloud.png')
    wordcloud.to_file("wordcloud.png")
if __name__ == "__main__":
    app.run(debug=True)